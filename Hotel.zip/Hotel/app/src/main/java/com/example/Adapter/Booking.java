package com.example.Adapter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.hotel.Description;
import com.example.hotel.MapsActivity;
import com.example.hotel.R;


public class Booking extends AppCompatActivity {
    TextView Showmore;
    ImageView map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.booking_page);


//show more description activity

        Showmore=findViewById(R.id.show_more);
        map=findViewById(R.id.map);
        Showmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Booking.this, Description.class));
            }
        });
        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Booking.this, MapsActivity.class));
            }
        });
    }
}