package com.example.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.Domain.Dharamshala;
import com.example.Domain.Dharamshalas;
import com.example.hotel.R;

import java.util.List;

public class FeaturedAdapter extends RecyclerView.Adapter<FeaturedAdapter.ViewHolder> {

    List<Dharamshalas> dharamshalasList;
    Context context;
    public FeaturedAdapter(Context applicationContext, List<Dharamshalas> dharamshalasList) {

        this.context=applicationContext;
        this.dharamshalasList=dharamshalasList;
    }




    @NonNull

    @Override
    public ViewHolder onCreateViewHolder(@NonNull   ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.single_dharamshala_view,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull   FeaturedAdapter.ViewHolder holder, int position) {
        holder.name.setText(dharamshalasList.get(position).getName());
       holder.addrs.setText(dharamshalasList.get(position).getAddrress());
        Glide.with(context).load(dharamshalasList.get(position).getImgUrl1()).into(holder.drmimg);

    }

    @Override
    public int getItemCount() {
        return dharamshalasList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        ImageView drmimg;
        TextView name,addrs;

        public ViewHolder(@NonNull   View itemView) {
            super(itemView);
            drmimg=itemView.findViewById(R.id.dharamshala_image);
            addrs=itemView.findViewById(R.id.dharamshala_adderess);
            name=itemView.findViewById(R.id.dharamshala_name);
        }
    }
}
