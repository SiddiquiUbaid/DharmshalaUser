package com.example.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.Domain.Dharamshala;
import com.example.hotel.R;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class HotelListAdapter extends RecyclerView.Adapter<HotelListAdapter.ViewHolder> {
    Context context;
    List<Dharamshala> dharamshalaList;

    public HotelListAdapter(Context applicationContext, List<Dharamshala> dharamshalaList) {
        this.context=applicationContext;
        this.dharamshalaList=dharamshalaList;

    }

    @NonNull

    @Override
    public ViewHolder onCreateViewHolder(@NonNull   ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.single_hotelforlist,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull ViewHolder holder, int position) {
        holder.name.setText(dharamshalaList.get(position).getName());
        holder.addrs.setText(dharamshalaList.get(position).getAddress());


        String s=Double.toString((double) dharamshalaList.get(position).getRating());
        holder.rating.setText(s);
if(dharamshalaList.get(position).getRating()>3){
     holder.rating.setBackgroundColor(Color.parseColor("#7CFC00"));

}
else if (dharamshalaList.get(position).getRating()<=3 && dharamshalaList.get(position).getRating()>=2){
    holder.rating.setBackgroundColor(Color.parseColor("#FFFF00"));
}else{holder.rating.setBackgroundColor(Color.parseColor("#FF0000"));

}
        Glide.with(context).load(dharamshalaList.get(position).getImgUrl1()).into(holder.drmimg);

    }


    @Override
    public int getItemCount() {
        return dharamshalaList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        ImageView drmimg;
        TextView name,addrs,rating;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            drmimg=itemView.findViewById(R.id.firstimage);
            rating=itemView.findViewById(R.id.rating);
            addrs=itemView.findViewById(R.id.hoteladdress);
            name=itemView.findViewById(R.id.hotelname);
        }
    }
}
