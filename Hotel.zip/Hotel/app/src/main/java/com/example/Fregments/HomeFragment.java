package com.example.Fregments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.Adapter.CityAdapter;
import com.example.Adapter.FeaturedAdapter;
import com.example.Adapter.TempleAdapter;
import com.example.Domain.City;
import com.example.Domain.Dharamshalas;
import com.example.Domain.Temples;
import com.example.hotel.HotelListActivity;
import com.example.hotel.R;
import com.example.hotel.currentLocation;
import com.example.hotel.demo;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;


public class HomeFragment extends Fragment {

    private FirebaseFirestore mstore;
    //city view
    private List<City> mCityList;
    private CityAdapter mCityAdapter;
    private RecyclerView mCityrecycler;
    //Featured View
    private List<Dharamshalas> dharamshalasList;
    private FeaturedAdapter featuredAdapter;
    private RecyclerView featureRecycler;

//nearby temples
    private List<Temples> templesList;
    private TempleAdapter templeAdapter;
    private RecyclerView templeRecycler;
    TextView featured;

    //gps
    ImageView gps;

    public HomeFragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View view= inflater.inflate(R.layout.fragment_home, container, false);
        mstore=FirebaseFirestore.getInstance();


        //gps current location
        gps = view.findViewById(R.id.gps);
        gps.setOnClickListener(new View.OnClickListener() {
                                   @Override
                                   public void onClick(View view) {
                                       Intent intent = new Intent(getActivity(), currentLocation.class);
                                       startActivity(intent);
                                   }
                               }
        );



        featured=view.findViewById(R.id.featured);
        featured.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getContext(), demo.class);
                startActivity(intent);
            }
        });
        templesList=new ArrayList<Temples>();
        templeRecycler= view.findViewById(R.id.templerecycler);
        templeAdapter=new TempleAdapter(getContext(),templesList);
        templeRecycler.setLayoutManager(new LinearLayoutManager(getContext(),RecyclerView.HORIZONTAL,false));
        templeRecycler.setAdapter(templeAdapter);
        mstore.collection("Temples")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {

                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {

                            for (QueryDocumentSnapshot document : task.getResult()) {


                                Temples category=document.toObject(Temples.class);


                                templesList.add(category);
                                templeAdapter.notifyDataSetChanged();
                            }
                        } else
                        {
                            Toast.makeText(getContext(), "gg", Toast.LENGTH_SHORT).show();
                            Log.w("TAG", "Error getting documents.", task.getException());
                        }
                    }
                 });





        // explore nearby code
        mCityList=new ArrayList<City>();
        mCityrecycler= view.findViewById(R.id.explore_nearby_recycler);
        mCityAdapter=new CityAdapter(getContext(),mCityList);
        mCityrecycler.setLayoutManager(new LinearLayoutManager(getContext(),RecyclerView.HORIZONTAL,false));
        mCityrecycler.setAdapter(mCityAdapter);

        mstore.collection("City")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {

                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {

                            for (QueryDocumentSnapshot document : task.getResult()) {


                                City category=document.toObject(City.class);


                                mCityList.add(category);
                                mCityAdapter.notifyDataSetChanged();
                            }
                        } else
                        {
                            Toast.makeText(getContext(), "gg", Toast.LENGTH_SHORT).show();
                            Log.w("TAG", "Error getting documents.", task.getException());
                        }
                    }
                });//explore nearby code ends



        dharamshalasList=new ArrayList<Dharamshalas>();
        featureRecycler=view.findViewById(R.id.featured_recycler);
        featuredAdapter=new FeaturedAdapter(getContext(),dharamshalasList);
        featureRecycler.setLayoutManager(new LinearLayoutManager(getContext(),RecyclerView.HORIZONTAL,false));
        featureRecycler.setAdapter(featuredAdapter);

        mstore.collection("Dharamshalas")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {

                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {

                            for (QueryDocumentSnapshot document : task.getResult()) {


                                Dharamshalas dharamshala=document.toObject(Dharamshalas.class);


                                dharamshalasList.add(dharamshala);
                                featuredAdapter.notifyDataSetChanged();
                            }
                        } else
                        {
                            Toast.makeText(getContext(), "gg", Toast.LENGTH_SHORT).show();
                            Log.w("TAG", "Error getting documents.", task.getException());
                        }
                    }
                });//explore nearby code ends
        return  view;

    }
}