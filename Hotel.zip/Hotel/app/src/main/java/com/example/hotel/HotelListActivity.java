package com.example.hotel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.Adapter.FeaturedAdapter;
import com.example.Adapter.HotelListAdapter;
import com.example.Domain.Dharamshala;
import com.example.Domain.Dharamshalas;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class HotelListActivity extends AppCompatActivity {

    private List<Dharamshala> dharamshalaList;
    ImageView backimg;
    private HotelListAdapter hotelListAdapter;
    private RecyclerView featureRecycler;
    private FirebaseFirestore mstore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel_list);


        backimg=findViewById(R.id.backimage);
        backimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


mstore=FirebaseFirestore.getInstance();


        dharamshalaList=new ArrayList<Dharamshala>();
        featureRecycler=findViewById(R.id.listrecycler);
        hotelListAdapter=new HotelListAdapter(getApplicationContext(),dharamshalaList);
        featureRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext(),RecyclerView.VERTICAL,false));
        featureRecycler.setAdapter(hotelListAdapter);

        mstore.collection("Dharamshalas")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {

                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {

                            for (QueryDocumentSnapshot document : task.getResult()) {


                                Dharamshala dharamshala=document.toObject(Dharamshala.class);


                                dharamshalaList.add(dharamshala);
                                hotelListAdapter.notifyDataSetChanged();
                            }
                        } else
                        {
                            Toast.makeText(getApplicationContext(), "gg", Toast.LENGTH_SHORT).show();
                            Log.w("TAG", "Error getting documents.", task.getException());
                        }
                    }
                });





    }
}